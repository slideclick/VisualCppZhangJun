//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by RichEditDemo.rc
//
#define IDD_RICHEDITDEMO_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDC_EDIT                        1000
#define IDC_BTN_COLOR                   1001
#define IDC_BTN_FONT                    1002
#define IDC_BTN_SAVE                    1003
#define IDC_STATUS                      1004
#define IDC_BTN_LOAD                    1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
