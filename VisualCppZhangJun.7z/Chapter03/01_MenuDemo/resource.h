//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MenuDemo.rc
//
#define IDD_MENUDEMO_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       129
#define IDR_MENU2                       130
#define IDC_HIDE_MENU                   1000
#define ID_MI_CHECK                     32771
#define ID_MI_DISABLE                   32772
#define ID_MI_ENABLE                    32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
