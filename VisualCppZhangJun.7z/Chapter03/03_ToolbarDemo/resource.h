//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ToolbarDemo.rc
//
#define IDD_TOOLBARDEMO_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDR_TOOLBAR                     129
#define IDR_MENU                        131
#define ID_MI_TEST                      32773
#define ID_MI_DISABLE                   32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
