// ColorProgress.cpp : implementation file
//

#include "stdafx.h"
#include "ColorStatusBar.h"
#include "ColorProgress.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CColorProgress

CColorProgress::CColorProgress()
{
}

CColorProgress::~CColorProgress()
{
}


BEGIN_MESSAGE_MAP(CColorProgress, CStatic)
	//{{AFX_MSG_MAP(CColorProgress)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CColorProgress message handlers

void CColorProgress::SetRange(int nRange)
{

}

BOOL CColorProgress::Create(LPRECT prcWnd, COLORREF crBegin, COLOREF crEnd)
{

}
