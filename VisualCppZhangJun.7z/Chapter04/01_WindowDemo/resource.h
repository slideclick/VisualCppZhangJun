//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by res.rc
//
#define IDR_MAIN                        101
#define ID_MI_WND1_SHOW                 40001
#define ID_MI_WND1_HIDE                 40002
#define ID_MI_WND2_SHOW                 40003
#define ID_MI_WND2_HIDE                 40004
#define ID_MI_WND1_CREATE               40005
#define ID_MI_WND1_DESTROY              40006
#define ID_MI_WND2_CREATE               40007
#define ID_MI_WND2_DESTROY              40008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40009
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
