// ImagPathWnd.h: interface for the CImagPathWnd class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IMAGPATHWND_H__E9F37ABE_BEE3_4760_8745_832C8716EF9B__INCLUDED_)
#define AFX_IMAGPATHWND_H__E9F37ABE_BEE3_4760_8745_832C8716EF9B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\..\CLASSES\MyWnd.h"

class CImagPathWnd : public CMyWnd  
{
public:
	CImagPathWnd();
	virtual ~CImagPathWnd();

};

#endif // !defined(AFX_IMAGPATHWND_H__E9F37ABE_BEE3_4760_8745_832C8716EF9B__INCLUDED_)
