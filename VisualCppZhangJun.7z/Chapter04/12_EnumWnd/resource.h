//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by res.rc
//
#define IDD_MAIN                        101
#define IDI_MAIN                        102
#define IDI_DRAG                        103
#define IDC_TREE                        1000
#define IDC_EDT_DETAIL                  1001
#define IDC_DRAG                        1002
#define IDC_TIP                         1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
