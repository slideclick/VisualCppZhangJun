// ODBC_SourceDlg.h : header file
//

#if !defined(AFX_ODBC_SOURCEDLG_H__14FC085C_476B_44EB_9337_7BAB533EFD6B__INCLUDED_)
#define AFX_ODBC_SOURCEDLG_H__14FC085C_476B_44EB_9337_7BAB533EFD6B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CODBC_SourceDlg dialog

class CODBC_SourceDlg : public CDialog
{
// Construction
public:
	CODBC_SourceDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CODBC_SourceDlg)
	enum { IDD = IDD_ODBC_SOURCE_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CODBC_SourceDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CODBC_SourceDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBtnBrowse();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ODBC_SOURCEDLG_H__14FC085C_476B_44EB_9337_7BAB533EFD6B__INCLUDED_)
