//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BinData.rc
//
#define IDD_BINDATA_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_LIST                        1001
#define IDC_EDT_ID                      1002
#define IDC_EDT_NAME                    1003
#define IDC_PHOTO                       1004
#define IDC_BTN_BROWSE                  1005
#define IDC_BTN_ADD                     1006
#define IDC_BTN_EDIT                    1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
